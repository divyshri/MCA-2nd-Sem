/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExceptionHandling;

/**
 *
 * @author Rajesh Reddy
 */
public class Exc1 {
     
	public static void main(String args[]) {
	int d = 0;
	int a = 42 / d;
	}
	}

    

